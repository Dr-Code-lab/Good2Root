#include <stdio.h>

int main(int argc, char *argv[])
{
    int iVar1;
    char cVar2;
    unsigned int local_10;
    char local_9;
    int local_8;

    if (argc != 2) {
        printf("The only one string should be presented\n");
        return -1;
    }
    iVar1 = sscanf(argv[1],"%d %c %d",&local_10,&local_9,&local_8);
    if (iVar1 < 3) {
        printf("Not enough arguments: there should be 3 at least\n");
        return (-1);
    }
    switch(local_10) {
        case 0:
            cVar2 = 'q';
            if (local_8 != 0x309) {
                printf("if local_10 = %d, then local_8 = %d, local_9 = %c\n", local_10, 0x309, cVar2);
                return -1;
            }
        break;
        case 1:
            cVar2 = 'b';
            if (local_8 != 0xd6) {
                printf("if local_10 = %d, then local_8 = %d, local_9 = %c\n", local_10, 0xd6, cVar2);
                return -1;
            }
            break;
        case 2:
            cVar2 = 'b';
            if (local_8 != 0x2f3) {
                printf("if local_10 = %d, then local_8 = %d, local_9 = %c\n", local_10, 0x2f3, cVar2);
                return -1;
            }
            break;
        case 3:
            cVar2 = 'k';
            if (local_8 != 0xfb) {
                printf("if local_10 = %d, then local_8 = %d, local_9 = %c\n", local_10, 0xfb, cVar2);
                return -1;
            }
            break;
        case 4:
            cVar2 = 'o';
            if (local_8 != 0xa0) {
                printf("if local_10 = %d, then local_8 = %d, local_9 = %c\n", local_10, 0xa0, cVar2);
                return -1;
            }
            break;  
        case 5:
            cVar2 = 't';
            if (local_8 != 0x1ca) {
                printf("if local_10 = %d, then local_8 = %d, local_9 = %c\n", local_10, 0x1ca, cVar2);
                return -1;
            }
            break;
        case 6:
            cVar2 = 'v';
            if (local_8 != 0x30c) {
                printf("if local_10 = %d, then local_8 = %d, local_9 = %c\n", local_10, 0x30c, cVar2);
                return -1;
            }
            break;
        case 7:
            cVar2 = 'b';
            if (local_8 != 0x20c) {
                printf("if local_10 = %d, then local_8 = %d, local_9 = %c\n", local_10, 0x20c, cVar2);
                return -1;
            }
            break;
        default:
            cVar2 = 'x';
            printf("0 <= local_10 <= 7\n");
            return -1;
    }
    if (cVar2 != local_9) {
        printf("if local_10 = %d, then local_8 = %d, local_9 = %c\n", local_10, 0x20c, cVar2);
        return -1;
    }
    return 0;
}