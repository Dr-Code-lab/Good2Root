#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char    array123[] = "isrveawhobpnutfg";

int     main(void)
{
    int     iVar1;
    char    local_c[8] = {0};
    char    *kekw = "giants";
    char    test[8] = {0};

    iVar1 = 0;
    do {
    for (int i = 98; i < 123; ++i) {
        test[iVar1] = i; 
        local_c[iVar1] = array123[test[iVar1] & 0xF];
        if (local_c[iVar1] == kekw[iVar1]) break ;
    }
    ++iVar1;
    } while (iVar1 < 6);
    printf("local_c = %s\n", local_c);
    printf("test = %s\n", test);
    iVar1 = strcmp(local_c,"giants");
    if (iVar1 != 0) {
        printf("strings are not equal\n");
        return -1;
    }
    printf("test = %s\n", test);
    return 0;
}