#include <stdio.h>

int func4(int param_1)
{
    int iVar1;
    int iVar2;

    if (param_1 < 2) {
        iVar2 = 1;
    }
    else {
        iVar1 = func4(param_1 - 1);
        iVar2 = func4(param_1 - 2);
        iVar2 = iVar2 + iVar1;
    }
    return iVar2;
}

int main(int argc, char *argv[])
{
    int iVar1;
    int local_8;

     if (argc != 2) {
        printf("The only one string should be presented\n");
        return -1;
    }
    iVar1 = sscanf(argv[1],"%d",&local_8);
    if ((iVar1 != 1) || (local_8 < 1)) {
        printf("wrong number of variables, local_8 < 1");
        return -1;
    }
    iVar1 = func4(local_8);
    printf("iVar1 = %d\n", iVar1);
    if (iVar1 != 55) { //0x37
        printf("iVar != 55\n");
        return -1;
    }
    return 0;
}