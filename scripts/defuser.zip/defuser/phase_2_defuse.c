#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	if (argc != 7) {
		printf("There should be 6 arguments");
		return -1;
	}
	int	aiStack_20[7];
	
	for (int i = 1; i < 7; ++i)
		aiStack_20[i] = atoi(argv[i]);
	if (aiStack_20[1] != 1) {
		printf("the first number should be '1'\n");
		return -1;
  	}
  	int iVar = 1;
  	do {
		if (aiStack_20[iVar + 1] != (iVar + 1) * aiStack_20[iVar]) {
			printf("aiStack_20[%d] != %d\n", iVar + 1, aiStack_20[iVar] * (iVar + 1));
			return -1;
		}
    	++iVar;
  	} while (iVar < 6);
  	return 0;
}
