#include <stdio.h>

//nodes = {253} -> {725} -> {301} -> {997} -> {212} -> {432}

int nodes[] = {253, 725, 301, 997, 212, 432};

void  swap(int *a, int *b) {
  int tmp = *a;
  *a = *b;
  *b = tmp;
}

int main(void) {
  int var[6];
  for (int i = 0; i < 6; ++i) var[i] = i + 1;
  for (int i = 0; i < 5; ++i) {
    for (int j = i + 1; j < 6; ++j) {
      if (nodes[i] < nodes[j]) {
        swap(&nodes[i], &nodes[j]);
        swap(&var[i], &var[j]);
      }
    }
  }
  for (int i = 0; i < 6; ++i) printf("%d ", nodes[i]);
  printf("\n");
  for (int i = 0; i < 6; ++i) printf("%d ", var[i]);
  printf("\n");
  return 0;
}